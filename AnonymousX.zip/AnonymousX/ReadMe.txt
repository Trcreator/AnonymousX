Hello! Thanks for using AnonymousX (Made by filip)

AnonymousX Roblox Exploit Hack
-------------------------------
If the AnonymousX is not working try turn off windows defender or try extracting everything!

╔╦═╦══════════════════╦╦╦╦╗
║║║╠═╦═╦═╦╦╦══╦═╦╗╔╦══╬╗╔╝║
║║╩║║║║║║║║║║║║║║╚╝╠╗╚╬╝╚╗║
║╚╩╩╩╩═╩╩╬╗╠╩╩╩═╩══╩══╩╩╩╝║
╚════════╩═╩══════════════╝ 

The hack is 100% safe and dosent have a virus!